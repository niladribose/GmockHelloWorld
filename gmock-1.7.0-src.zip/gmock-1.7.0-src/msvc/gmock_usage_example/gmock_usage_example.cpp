// gmock_usage_example.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "gmock\gmock.h"
#include "gtest\gtest.h"



TEST(TestSuiteName,TestName)
{


}